package com.eterces.mybauet;

public class ValueForSemester {
    public static final String STORAGE_PATH_UPLOADS1 = "semester1/";
    public static final String DATABASE_PATH_UPLOADS1 = "semester1";

    public static final String STORAGE_PATH_UPLOADS2 = "semester2/";
    public static final String DATABASE_PATH_UPLOADS2 = "semester2";

    public static final String STORAGE_PATH_UPLOADS3 = "semester3/";
    public static final String DATABASE_PATH_UPLOADS3 = "semester3";

    public static final String STORAGE_PATH_UPLOADS4 = "semester4/";
    public static final String DATABASE_PATH_UPLOADS4 = "semester4";

    public static final String STORAGE_PATH_UPLOADS5 = "semester5/";
    public static final String DATABASE_PATH_UPLOADS5 = "semester5";

    public static final String STORAGE_PATH_UPLOADS6 = "semester6/";
    public static final String DATABASE_PATH_UPLOADS6 = "semester6";

    public static final String STORAGE_PATH_UPLOADS7 = "semester7/";
    public static final String DATABASE_PATH_UPLOADS7 = "semester7";

    public static final String STORAGE_PATH_UPLOADS8 = "semester8/";
    public static final String DATABASE_PATH_UPLOADS8 = "semester8";




    public static final String qSTORAGE_PATH_UPLOADS1 = "semesterQtn1/";
    public static final String qDATABASE_PATH_UPLOADS1 = "semesterQtn1";

    public static final String qSTORAGE_PATH_UPLOADS2 = "semesterQtn2/";
    public static final String qDATABASE_PATH_UPLOADS2 = "semesterQtn2";

    public static final String qSTORAGE_PATH_UPLOADS3 = "semesterQtn3/";
    public static final String qDATABASE_PATH_UPLOADS3 = "semesterQtn3";

    public static final String qSTORAGE_PATH_UPLOADS4 = "semesterQtn4/";
    public static final String qDATABASE_PATH_UPLOADS4 = "semesterQtn4";

    public static final String qSTORAGE_PATH_UPLOADS5 = "semesterQtn5/";
    public static final String qDATABASE_PATH_UPLOADS5 = "semesterQtn5";

    public static final String qSTORAGE_PATH_UPLOADS6 = "semesterQtn6/";
    public static final String qDATABASE_PATH_UPLOADS6 = "semesterQtn6";

    public static final String qSTORAGE_PATH_UPLOADS7 = "semesterQtn7/";
    public static final String qDATABASE_PATH_UPLOADS7 = "semesterQtn7";

    public static final String qSTORAGE_PATH_UPLOADS8 = "semesterQtn8/";
    public static final String qDATABASE_PATH_UPLOADS8 = "semesterQtn8";


}
